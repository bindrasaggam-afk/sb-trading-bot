package com.sb.backend.market.model

data class DepthLevel(
    val price: Double = 0.0,
    val quantity: Long = 0L,
    val orders: Int = 0
)

data class InstrumentKey(
    val exchange: String,
    val symbol: String
) {
    fun key(): String =
        "${exchange.trim().toUpperCase()}|${symbol.trim().toUpperCase()}"
}

data class MarketTick(
    val key: InstrumentKey,
    val ltp: Double = 0.0,
    val open: Double? = null,
    val high: Double? = null,
    val low: Double? = null,
    val close: Double? = null,
    val previousClose: Double? = null,
    val volume: Long = 0L,
    val change: Double? = null,
    val changePercent: Double? = null,
    val bidPrice: Double? = null,
    val bidQty: Long? = null,
    val askPrice: Double? = null,
    val askQty: Long? = null,
    val bids: List<DepthLevel> = emptyList(),
    val asks: List<DepthLevel> = emptyList(),
    val totalBuyQty: Long = 0L,
    val totalSellQty: Long = 0L,
    val oi: Long = 0L,
    val lastTradeQty: Long = 0L,
    val lastTradeTime: Long? = null,
    val exchangeTime: Long? = null,
    val receivedAt: Long = System.currentTimeMillis(),
    val isIndex: Boolean = false
)

data class MarketCandle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long = 0L
)

enum class MarketTimeframe(
    val label: String,
    val seconds: Long
) {
    MIN_1("1m", 60L),
    MIN_2("2m", 120L),
    MIN_3("3m", 180L),
    MIN_5("5m", 300L),
    MIN_10("10m", 600L),
    MIN_15("15m", 900L),
    MIN_30("30m", 1_800L),
    HOUR_1("1h", 3_600L),
    HOUR_4("4h", 14_400L),
    DAY_1("1D", 86_400L),
    WEEK_1("1W", 604_800L),
    WEEK_2("2W", 1_209_600L),
    WEEK_4("4W", 2_419_200L),
    MONTH_1("1M", 2_592_000L),
    MONTH_3("3M", 7_776_000L),
    YEAR_1("1Y", 31_536_000L),
    YEAR_5("5Y", 157_680_000L);

    companion object {
        fun fromLabel(label: String): MarketTimeframe? {
            val trimmed = label.trim()
            return values().firstOrNull { it.label == trimmed }
                ?: values().firstOrNull {
                    it.label.equals(trimmed, ignoreCase = true)
                }
        }
    }
}

data class MarketUiState(
    val key: InstrumentKey? = null,
    val tick: MarketTick? = null,
    val isSubscribed: Boolean = false,
    val isConnected: Boolean = false,
    val isAuthenticated: Boolean = false,
    val connection: String = "DISCONNECTED",
    val timeframe: String = "1m",
    val status: String = "IDLE",
    val lastUpdated: Long = 0L
)
